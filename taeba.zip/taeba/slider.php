		<div id="slider">
			<!-- Begin Shell -->
			<div class="shell">
				<ul class="slider-items">
					<li>
						<img src="images/s1.png" alt="Slide Image" />
						<div class="slide-entry">
							<h2><span> Islamic</span> Woman Cabaya</h2>
					
							<a href="products.php" class="button" title="Buy now"><span>Buy now</span></a>
						</div>
					</li>
					<li>
						<img src="images/s2.png" alt="Slide Image" />
						<div class="slide-entry">
							<h4><span>Islamic</span><span class="small"></span> &nbsp; Man Dresses</h4>
							
							<a href="products.php" class="button" title="Buy now"><span>Buy now</span></a>
						</div>
					</li>
					<li>
						<img src="images/s3.png" alt="Slide Image" />
						<div class="slide-entry">
							<h3><span>Black Suit</span><span class="small"> </span>Dress<span class="small"> And Coats</span></h3> 
					
						
							<a href="products.php" class="button" title="Buy now"><span>Buy now</span></a>
						</div>
					</li>
							<li>
						<img src="images/s4.png" alt="Slide Image" />
						<div class="slide-entry">
							<h3><span> Choose</span><span class="small"> Frush</span>Fruits</h3> 
							
							<a href="products.php" class="button" title="Buy now"><span>Buy now</span></a>
						</div>
					</li>
					<li>
						<img src="images/s5.png" alt="Slide Image" />
						<div class="slide-entry">
							<h4><span>Some Fruits</span><span class="small">&amp;</span><span>Frush</span>Crops</h4>
							<a href="products.php" class="button" title="Buy now"><span>Buy now</span></a>
						</div>
					</li>
					<li>
						<img src="images/s6.png" alt="Slide Image" />
						<div class="slide-entry">
							<h3><span>Smart Dress</span><span class="small">of </span> Male And Females Suits</h3> 
					
							
							<a href="products.php" class="button" title="Buy now"><span>Buy now</span></a>
						</div>
					</li>
					<li>
						<img src="images/s7.png" alt="Slide Image" />
						<div class="slide-entry">
							<h2><span>Woman</span>Dress</h2>
						
							<a href="products.php" class="button" title="Buy now"><span>Buy now</span></a>
						</div>
					</li>
					<li>
						<img src="images/s8.png" alt="Slide Image" />
						<div class="slide-entry">
							<h4><span>Frush</span><span class="small"></span> &nbsp;<span> Food</span>  New Crops</h4>
							
							<a href="products.php" class="button" title="Buy now"><span>Buy now</span></a>
						</div>
					</li>
					<li>
						<img src="images/s9.png" alt="Slide Image" />
						<div class="slide-entry">
					
							<h4 class="short"><span>Home</span> Cleaning Equipment</h4>
							
							<a href="products.php" class="button" title="Buy now"><span>Buy now</span></a>
						</div>
					</li>
				</ul>
				<div class="cl">&nbsp;</div>
				<div class="slider-nav">
					
				</div>
			</div>
			<!-- End Shell -->
		</div>