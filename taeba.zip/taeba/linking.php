        <title>Somstore eCommerce - </title>
        <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
        <link rel="icon" type="image" href="images/favicon.png<?php echo '?'.mt_rand(); ?>" />
		<meta name="description" content="Somstore Online Sales System">
		<meta name="keywords" content="Somstore Online Sales System">
		<meta name="author" content="ABDIRAHMAN ALI ABDI">
		<meta charset="UTF-8">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
    <link rel="stylesheet" href="assets/font-awesome/css/all.min.css<?php echo '?'.mt_rand(); ?>">


    
  <!-- Template Main CSS File -->
        <link rel="stylesheet" href="css/style.css<?php echo '?'.mt_rand(); ?>" type="text/css" media="all" />
		<link rel="stylesheet" href="css/proStyle.css<?php echo '?'.mt_rand(); ?>" type="text/css" media="all" />
	   	<link rel="stylesheet" href="css/userlogin.css<?php echo '?'.mt_rand(); ?>" type="text/css" media="all" />
	 	<link rel="stylesheet" href="css/cart.css<?php echo '?'.mt_rand(); ?>" type="text/css" media="all" />
	    <link rel="stylesheet" href="css/chatStyle.css<?php echo '?'.mt_rand(); ?>" type="text/css" media="screen" /> 
	    <link rel="stylesheet" href="css/logFile.css<?php echo '?'.mt_rand(); ?>"  type="text/css" media="screen" />
	    <link rel="stylesheet" href="css/audioplayer.css<?php echo '?'.mt_rand(); ?>"  type="text/css" media="screen" />
		<link rel="stylesheet" type="text/css" href="css/animate.css<?php echo '?'.mt_rand(); ?>" />
	
     
		
		 
     
	 <script>
			/*
				VIEWPORT BUG FIX
				iOS viewport scaling bug fix, by @mathias, @cheeaun and @jdalton
			*/
			(function(doc){var addEvent='addEventListener',type='gesturestart',qsa='querySelectorAll',scales=[1,1],meta=qsa in doc?doc[qsa]('meta[name=viewport]'):[];function fix(){meta.content='width=device-width,minimum-scale='+scales[0]+',maximum-scale='+scales[1];doc.removeEventListener(type,fix,true);}if((meta=meta[meta.length-1])&&addEvent in doc){fix();scales=[.25,1.6];doc[addEvent](type,fix,true);}}(document));
		</script>
	<script src="js/jquery-1.6.2.min.js" type="text/javascript" charset="utf-8"></script>

	<script src="js/cufon-yui.js" type="text/javascript"></script>
	<script src="js/Myriad_Pro_700.font.js" type="text/javascript"></script>
	<script src="js/jquery.jcarousel.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/functions.js" type="text/javascript" charset="utf-8"></script>
	
	
	 <!-- Linking scripts -->
    <script src="js/main.js" type="text/javascript"></script>
	
	